NOVA CHAMPIONS Android WebView project

Loads the live website:
https://novachampions.github.io/NOVA-CHAMPIONS/

Implements WebChromeClient.onShowFileChooser and Android ACTION_GET_CONTENT
for HTML image inputs.

BUILD USING GITHUB ACTIONS (can be done from an Android phone):
1. Create a new GitHub repository named NOVA-CHAMPIONS-ANDROID.
2. Extract this ZIP on your phone.
3. Upload the CONTENTS of the extracted folder to the repository root.
   Make sure .github/workflows/build-apk.yml is included.
4. Open the repository's Actions tab and enable Actions if prompted.
5. Select "Build NOVA CHAMPIONS APK" then press "Run workflow".
6. When the run succeeds, open it and download the NOVA-CHAMPIONS-APK artifact.
7. Extract that artifact ZIP and install app-debug.apk.

IMPORTANT:
- This does not modify the existing GitHub Pages website or old APK.
- First build is debug-signed. If Android refuses installation over the old APK,
  uninstall the old APK first, then install this one.
- Firebase data is stored in the cloud and should remain available after reinstall.
- Package: com.novachampions.official; version 2.0.0 (code 2).
- Test both team-logo and news-image uploads after installation.
